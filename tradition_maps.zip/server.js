#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');

mongoose.connect('mongodb://admin:secret@localhost:27017/places?authSource=admin', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const placeSchema = new mongoose.Schema({
    title: String,
    description: String,
    category: String,
    latitude: Number,
    longitude: Number,
    youtube: String,
    google: String,
    visitgreece: String
});

const Place = mongoose.model('Place', placeSchema, 'places');



// module dependencies
var express = require('express');

// get port from environment and store in Express
var app = express();

// set the view engine to ejs
app.set('view engine', 'ejs');

// use res.render to load up an ejs view file
// index page
app.get('/', function(req, res) {
	res.render('pages/index');
});

// about page
app.get('/about', function(req, res) {
	res.render('pages/about');
});



app.get('/info', async (req, res) => {
    try {
        console.log('Connecting to MongoDB...');
        const places = await Place.find({});
        console.log('Fetched places:', places.length);
        res.render('pages/info', { places });
    } catch (err) {
        console.error('Error loading places:', err);
        res.status(500).json({ error: 'Failed to load places from DB' });
    }
});

// app.get('/info', (req, res) => {
//     fs.readFile(path.join(__dirname, 'places.json'), 'utf8', (err, data) => {
//         if (err) {
//             return res.status(500).json({ error: 'Failed to load places' });
//         }
//         const places = JSON.parse(data);
//         res.render('pages/info', { places }); // Pass the places data to info.ejs
//     });
// });
// // info page
// app.get('/info', function(req, res) {
// 	res.render('pages/info');
// });


app.get('/places', async (req, res) => {
    try {
        const places = await Place.find({});
        res.json(places);
    } catch (err) {
        console.error('Failed to fetch places from MongoDB:', err);
        res.status(500).json({ error: 'Failed to fetch places from DB' });
    }
});

// Endpoint to send places.json
// app.get('/places', (req, res) => {
//     fs.readFile(path.join(__dirname, 'places.json'), 'utf8', (err, data) => {
//         if (err) {
//             return res.status(500).json({ error: 'Failed to load places' });
//         }
//         res.json(JSON.parse(data));
//     });
// });

// Get port from environment and store in Express
var port = process.env.PORT || 3000;
app.listen(port)
console.log('Server is listening on port', port)
